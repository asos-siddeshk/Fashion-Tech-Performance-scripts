package xmlcreator;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import com.google.gson.Gson;

import utilities.DbConnections;

public class ItemIntegrationMessages {

	public static int counter = 40000;
	public static int loop = 40000;
	public static void main(String[] args) throws Throwable {
		
		
		
		String sampleJsonFile = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType1.json"));
		JSONObject jObject  = new JSONObject(sampleJsonFile);
		/*File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);*/
        int count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
		jObject.put("_id","Item_1000"+counter);
		jObject.put("ItemNo","1000"+counter);
		jObject.getJSONObject("itemHdrDesc").put("ItemNo","1000"+counter);
		System.out.println(jObject);
		String notificationFileName = "ItemMessageType_1_"/* + orderIds.get(i)[0] +*/ +count +".json";
		File notificationFile = new File("src/test/resources/messagetype1/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        
        /*String sampleJsonFile2 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType2.json"));
		JSONObject jObject2  = new JSONObject(sampleJsonFile2);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        jObject2.put("_id","ItemUDALOV_1000"+counter+"_35_1");
        jObject2.put("ItemNo","1000"+counter);
		System.out.println(jObject2);
		String notificationFileName = "ItemMessageType_2_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype2/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject2.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        String sampleJsonFile3 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType3.json"));
		JSONObject jObject3  = new JSONObject(sampleJsonFile3);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject3.put("ItemNo","1000"+counter);
        jObject3.put("_id","ItemUDALOV_1000"+counter+"_37_1");
		System.out.println(jObject3);
		String notificationFileName = "ItemMessageType_3_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype3/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject3.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        String sampleJsonFile4 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType4.json"));
		JSONObject jObject4  = new JSONObject(sampleJsonFile4);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject4.put("ItemNo","1000"+counter);
        jObject4.put("_id","ItemUDADate_1000"+counter+"_50");
		System.out.println(jObject4);
		String notificationFileName = "ItemMessageType_4_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype4/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject4.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        String sampleJsonFile5 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType5.json"));
		JSONObject jObject5  = new JSONObject(sampleJsonFile5);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject5.put("ItemNo","1000"+counter);
        jObject5.put("_id","ItemSup_1000"+counter+"_2100002053");
		System.out.println(jObject5);
		String notificationFileName = "ItemMessageType_5_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype5/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject5.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        
        String sampleJsonFile6 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType6.json"));
		JSONObject jObject6  = new JSONObject(sampleJsonFile6);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject6.put("ItemNo","1000"+counter);
        jObject6.put("_id","ItemSupCty_1000"+counter+"_2100002053_IN");
		System.out.println(jObject6);
		String notificationFileName = "ItemMessageType_6_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype6/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject6.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        String sampleJsonFile7 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType7.json"));
		JSONObject jObject7  = new JSONObject(sampleJsonFile7);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject7.put("ItemNo","1000"+counter);
        jObject7.put("_id","ISCMfr_1000"+counter+"_2100002053_IN");
		System.out.println(jObject7);
		String notificationFileName = "ItemMessageType_7_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype7/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject7.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        
        String sampleJsonFile8 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType8.json"));
		JSONObject jObject8  = new JSONObject(sampleJsonFile8);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject8.put("ItemNo","1000"+counter);
        jObject8.put("_id","ItemUPC_1000"+counter+"_2200009003332");
		System.out.println(jObject8);
		String notificationFileName = "ItemMessageType_8_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype8/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject8.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }
        
        
        String sampleJsonFile9 = FileUtils.readFileToString(new File("src/test/java/xmlcreator/MessageType9.json"));
		JSONObject jObject9  = new JSONObject(sampleJsonFile9);
		File[] blobList = csvSourceFileForBlob.listFiles();
		System.out.println("List size:"+blobList.length);
        count = 0;
        counter = 40000;
        for (int j =0; j<40000; j++){
        count++;
        counter++;
        //System.out.println(counter);
        jObject9.put("ItemNo","1000"+counter);
        jObject9.put("_id","ISCDim_1000"+counter+"_2100002053_IN_EA");
		System.out.println(jObject9);
		String notificationFileName = "ItemMessageType_9_" + orderIds.get(i)[0] + +count +".json";
		File notificationFile = new File("src/test/resources/messagetype9/" + notificationFileName);
		notificationFile.createNewFile();
		FileWriter notificationFileWriter = new FileWriter(notificationFile);
		notificationFileWriter.write(jObject9.toString());
		notificationFileWriter.flush();
		notificationFileWriter.close();
        }*/
        
		}

	}



