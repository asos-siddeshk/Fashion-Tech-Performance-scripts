package utilities;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;






public class TestBase {
	public Properties loginCreds = null;

	public static String styleid;
	public static String suppName;
	public static int UITimeout;
	public static int UIPollingCount;

	public TestBase() throws IOException {
		InputStream input = new FileInputStream("src/test/resources/Config/Config.properties");
		loginCreds = new Properties();
		loginCreds.load(input);
	}
	public String Environment() {
		return loginCreds.getProperty("Environment");
	}

	public String RmsDb_Uri() {
		return loginCreds.getProperty(Environment() + ".rms_db.uri");
	}

	public String RmsDb_Username() {
		return loginCreds.getProperty(Environment() + ".rms_db.username");
	}

	public String RmsDb_Password() {
		return loginCreds.getProperty(Environment() + ".rms_db.password");
	}



}
