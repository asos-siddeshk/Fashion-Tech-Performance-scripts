package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;



public class DbConnections {
	
	
	public Connection getRMSDBConnection() throws Exception {
		//TestBase Credintials = new TestBase();
		TestBase Credintials = new TestBase();
		String RMS_Uri = Credintials.RmsDb_Uri();
		String RMSdb_username = Credintials.RmsDb_Username();
		String RMSdb_password = Credintials.RmsDb_Password();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection(RMS_Uri, RMSdb_username, RMSdb_password);
		return conn;
	}

	
	public ArrayList<String[]> returnSqlQueryResults(String query) throws Throwable {
		ArrayList<String[]> result = new ArrayList<String[]>();
		Connection con = null;
		Statement stmt = null;
		ResultSet rsSQL = null;
		boolean res = false;
		try {
			con = getRMSDBConnection();
			stmt = con.createStatement();
			rsSQL = stmt.executeQuery(query);
			
			int columncount = rsSQL.getMetaData().getColumnCount();
			
			while (rsSQL.next()) {
				
				String[] row = new String[columncount];
				for (int i = 0; i < columncount; i++) {
					row[i] = rsSQL.getString(i + 1);
				}
				result.add(row);
			}
			res = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (rsSQL != null) {
				rsSQL.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (con != null) {
				con.close();
			}
		}

		return result;

	}
	
	
	
	
}
