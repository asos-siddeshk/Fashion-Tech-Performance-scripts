package xmlcreator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import BookingDatesXML.Dcsextractdata;
import BookingDatesXML.Dcsextractdata.Dataheaders;
import BookingDatesXML.Dcsextractdata.Dataheaders.Dataheader;
import utilities.DbConnections;

/**
 * The Class BookingDates.
 */
public class BookingDates_FC04 {
	
	/** The dataheader. */
	static Dataheader dataheader = new Dataheader();
	static Dcsextractdata dcsextractdata = new Dcsextractdata();
	static ArrayList<Dataheader> dataheaderList = new ArrayList<Dataheader>();
	static Dataheaders dataheaders = new Dataheaders();
	static int filecount,j,k,count=0;
	static DbConnections dbConnect = new DbConnections();
	static ArrayList<String[]> results = new ArrayList<String[]>();
	static ArrayList<String[]> resultsOut = new ArrayList<String[]>();
	static ArrayList<String[]> resultsFC01 = new ArrayList<String[]>();
	static ArrayList<String[]> resultsFC03 = new ArrayList<String[]>();
	static ArrayList<String[]> resultsFC04 = new ArrayList<String[]>();
	static StringBuffer Finalxml = new StringBuffer() ;
	public static File testingDirectory = new File("C:\\Workspace\\bookingDates\\src\\test\\resources\\testdataFC04");
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Throwable the throwable
	 */
	public static void main(String[] args) throws Throwable {

		JAXBContext contextObj = JAXBContext.newInstance(Dcsextractdata.class);
		Marshaller marshallerObj = contextObj.createMarshaller();
		marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		
		results = dbConnect.returnSqlQueryResults("select sh.SHIPMENT, sh.ORDER_NO, sh.ASN as reference_id, to_char(sh.SHIP_DATE+1,'YYYYmmddHHMISS')  as booking_dstamp,s.EXTERNAL_REF_ID as supplier_id, 'A'||s.EXTERNAL_REF_ID as bookref_id, wh.WH_NAME_SECONDARY as site_id from rms.shipment sh, rms.sups s, rms.ordhead oh, rms.wh wh where sh.order_no = oh.order_no and s.supplier = oh.supplier and sh.order_no is not null and sh.to_loc = wh.wh and sh.to_loc IN ('1','4','3') and status_code ='I' and rownum <= '6000' order by 1 desc");
		
		for(k=0; k<results.size(); k++){
			System.out.println("results.get(k)[6]:" +results.get(k)[6]);
			if(results.get(k)[6].equalsIgnoreCase("FC01")){
				resultsFC01.add(results.get(k));
			}
			else if(results.get(k)[6].equalsIgnoreCase("FC03")){
				resultsFC03.add(results.get(k));
			}
			else if(results.get(k)[6].equalsIgnoreCase("FC04")){
				resultsFC04.add(results.get(k));
			}
		}
		//Change line  -- 68,73,87,88,99/100,From 123 based on stores
		System.out.println("resultsFC04.size():" +resultsFC04.size());
		System.out.println("resultsFC01.size():" +resultsFC01.size());
		System.out.println("resultsFC03.size():" +resultsFC01.size());
		
		for (j=0; j<resultsFC04.size(); j++){
			if(j>0){
				marshallerObj.setProperty("jaxb.fragment", Boolean.TRUE);
			}
			dataheaders.getDataheader().add(getDataheadersinfo(j));
			dcsextractdata.setDataheaders(dataheaders);
			filecount++;
			marshallerObj.marshal(dcsextractdata, new FileOutputStream("src/test/resources/testdataFC04/BookingDate.xml"));
			String xml = FileUtils.readFileToString(new File("src/test/resources/testdataFC04/BookingDate.xml"));
			xml = xml.trim();
	/*FC04*///String fileName = "BookingDateFC04_" + filecount + ".xml";
	/*FC01*/String fileName = "BookingDateFC04_" + filecount + ".xml";
	/*FC01*///String fileName = "BookingDateFC01_" + filecount + ".xml";
			File file = new File("src/test/resources/testdataFC04/" + fileName);
			file.createNewFile();
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write(xml);
			fileWriter.flush();
			fileWriter.close();
			dcsextractdata.getDataheaders().getDataheader().clear();
			 
		}
		filecount=23;
		int test=0;
		String dummy = null;
	File[] fList = testingDirectory.listFiles();
    System.out.println("List size:"+fList.length);
    for (File tmp : fList){
    	test = test+1;
    	System.out.println("\n" +test);
    	count++;
    	//System.out.println("countOccurences(Finalxml.toString(), \"        </dataheader>\" :" +countOccurences(Finalxml.toString(), "        </dataheader>") );
    	if(!tmp.getName().equalsIgnoreCase("BookingDate.xml")){
    		if( !(countOccurences(Finalxml.toString(), "        </dataheader>" )>=500)){
        String content = new String(Files.readAllBytes(Paths.get(tmp.getPath())));
        if(dummy != null){
        	dummy = dummy.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
        	dummy = dummy.replace("<dcsextractdata>", "");
        	dummy = dummy.replace("<dataheaders>", "");
        	dummy = dummy.replace("</dataheaders>", "");
        	dummy = dummy.replace("</dcsextractdata>", "");
        	dummy = dummy.trim();
        	Finalxml = Finalxml.append(dummy);
        	dummy = null;
        }
        if(count>=2){
        	content = content.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
        	content = content.replace("<dcsextractdata>", "");
        	content = content.replace("<dataheaders>", "");
        	content = content.replace("</dataheaders>", "");
        	content = content.replace("</dcsextractdata>", "");
        	content = content.trim();
        	Finalxml = Finalxml.append("\n" +content);
        }
        else{
        	content = content.replace("</dataheaders>", "");
        	content = content.replace("</dcsextractdata>", "");
        	content = content.trim();
        	Finalxml = Finalxml.append(content);
        }
       if(test == fList.length){
    	   System.out.println("\n" +"**Enterted here**" + "when test was:" +test);
    	   Finalxml = Finalxml.append("\n");
    	   Finalxml = Finalxml.append("</dataheaders>");
    	   Finalxml = Finalxml.append("\n");
    	   Finalxml = Finalxml.append("</dcsextractdata>");
    	   filecount++;
   		String splitContent = Finalxml.toString().trim();
   		String xmlfileName = "BookingDateFC04_" + filecount + ".xml";
   				File file = new File("src/test/resources/bookingDatesFilesFC04/" + xmlfileName);
   				file.createNewFile();
   				FileWriter fileWriter = new FileWriter(file);
   				System.out.println(splitContent);
   				fileWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +"\n");
   				fileWriter.write("<dcsextractdata>" +"\n");
   				fileWriter.write("<dataheaders>" +"\n");
   				fileWriter.write(splitContent);
   				fileWriter.flush();
   				fileWriter.close();
   				String sampleJsonFile = FileUtils.readFileToString(new File("src/test/java/xmlcreator/sampleJsonFile.json"));
   				JSONObject jObject  = new JSONObject(sampleJsonFile);
   				jObject.getJSONObject("data").put("fileName",xmlfileName);
   				jObject.getJSONObject("data").put("blobUri","https://asbamintstgeuwvpt01.blob.core.windows.net/bam056-bookingdate-source/testDir/"+xmlfileName+"?sv=2017-04-17&sig=fgXfpo3x050olPT0uUsV3Idd1vaeKrjlf4n76DYNSvQ%3D&spr=https&st=2018-11-01T15%3A04%3A52Z&se=2019-08-28T15%3A09%3A52Z&srt=sco&ss=bfqt&sp=racupwdl");
   				jObject.getJSONObject("data").put("source","FC04");
   	/*	FC03*/	//jObject.getJSONObject("data").put("source","FC03");
    				System.out.println(jObject);
   				String notificationFileName = "BookingDateNotificationFC04_" +filecount+ ".json";
   				File notificationFile = new File("src/test/resources/notification/" + notificationFileName);
   				notificationFile.createNewFile();
   				FileWriter notificationFileWriter = new FileWriter(notificationFile);
   				notificationFileWriter.write(jObject.toString());
   				notificationFileWriter.flush();
   				notificationFileWriter.close();
   				Finalxml.delete(0, Finalxml.length());
       }
    }
    	else{
    		dummy = new String(Files.readAllBytes(Paths.get(tmp.getPath())));
    		Finalxml = Finalxml.append("\n");
      	   Finalxml = Finalxml.append("</dataheaders>");
      	   Finalxml = Finalxml.append("\n");
      	   Finalxml = Finalxml.append("</dcsextractdata>");
    		filecount++;
    		String splitContent = Finalxml.toString().trim();
    		/*FC04*/String xmlfileName = "BookingDateFC04_" + filecount + ".xml";
    				File file = new File("src/test/resources/bookingDatesFilesFC04/" + xmlfileName);
    				file.createNewFile();
    				FileWriter fileWriter = new FileWriter(file);
    				//System.out.println(splitContent);
    				fileWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +"\n");
       				fileWriter.write("<dcsextractdata>" +"\n");
       				fileWriter.write("<dataheaders>" +"\n");
    				fileWriter.write(splitContent);
    				fileWriter.flush();
    				fileWriter.close();
    				String sampleJsonFile = FileUtils.readFileToString(new File("src/test/java/xmlcreator/sampleJsonFile.json"));
    				JSONObject jObject  = new JSONObject(sampleJsonFile);
    				jObject.getJSONObject("data").put("fileName",xmlfileName);
    				jObject.getJSONObject("data").put("blobUri","https://asbamintstgeuwvpt01.blob.core.windows.net/bam056-bookingdate-source/testDir/"+xmlfileName+"?sv=2017-04-17&sig=fgXfpo3x050olPT0uUsV3Idd1vaeKrjlf4n76DYNSvQ%3D&spr=https&st=2018-11-01T15%3A04%3A52Z&se=2019-08-28T15%3A09%3A52Z&srt=sco&ss=bfqt&sp=racupwdl");
    		/*FC04*/	jObject.getJSONObject("data").put("source","FC04");
    		/*FC03*/	//jObject.getJSONObject("data").put("source","FC03");
    				System.out.println(jObject);
    				String notificationFileName = "BookingDateNotificationFC04_" +filecount+ ".json";
    				File notificationFile = new File("src/test/resources/notification/" + notificationFileName);
    				notificationFile.createNewFile();
    				FileWriter notificationFileWriter = new FileWriter(notificationFile);
    				notificationFileWriter.write(jObject.toString());
    				notificationFileWriter.flush();
    				notificationFileWriter.close();
    				Finalxml.delete(0, Finalxml.length());
    	}
    	}
    	
    }
   // System.out.println("*****************************" +Finalxml);
    
	}
	/**
	 * Gets the dataheadersinfo.
	 *
	 * @return the dataheadersinfo
	 */
	private static Dataheader getDataheadersinfo(int i) {

		/*Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");*/
		
		
		//FC04
		String bookingTimeStamp = resultsFC04.get(i)[3];
		System.out.println("bookingTimeStamp:" +bookingTimeStamp);

		dataheader.setRecordType("BKL");
		dataheader.setAction("E");
		dataheader.setCode("Add");
		dataheader.setBookrefId(resultsFC04.get(i)[5]);
		dataheader.setSiteId(resultsFC04.get(i)[6]);
		dataheader.setBookingDstamp(new Long(bookingTimeStamp));
		dataheader.setStatus("Scheduled");
		dataheader.setLocationId("EUROHUB");
		dataheader.setNoSlots(new Byte((byte) 4));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setActualCartons(new Byte((byte)0));
		dataheader.setActualPallets(new Byte((byte)0));
		System.out.println("setReferenceId:" +resultsFC04.get(i)[2]);
		dataheader.setReferenceId(resultsFC04.get(i)[2]);
		dataheader.setReferenceType("Pre-Advised");
		dataheader.setClientId("ASOS");
		dataheader.setSupplierId(resultsFC04.get(i)[4]);
		dataheader.setCarrierId(new Byte((byte)1));
		dataheader.setStationId("DOCDATA");
		dataheader.setUserId("003474");
		dataheader.setDstamp(new Long(bookingTimeStamp));
		dataheader.setUploaded("N");
		dataheader.setTimeZoneName("Europe/London");
		dataheader.setServiceLevel("");
		dataheader.setTrailerId("ex Holland");
		
		
		//FC03
		/*String bookingTimeStamp = resultsFC03.get(i)[3];
		System.out.println("bookingTimeStamp:" +bookingTimeStamp);

		dataheader.setRecordType("BKL");
		dataheader.setAction("E");
		dataheader.setCode("Add");
		dataheader.setBookrefId(resultsFC03.get(i)[5]);
		dataheader.setSiteId(resultsFC03.get(i)[6]);
		dataheader.setBookingDstamp(new Long(bookingTimeStamp));
		dataheader.setStatus("Scheduled");
		dataheader.setLocationId("EUROHUB");
		dataheader.setNoSlots(new Byte((byte) 4));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setActualCartons(new Byte((byte)0));
		dataheader.setActualPallets(new Byte((byte)0));
		System.out.println("setReferenceId:" +resultsFC03.get(i)[2]);
		dataheader.setReferenceId(resultsFC03.get(i)[2]);
		dataheader.setReferenceType("Pre-Advised");
		dataheader.setClientId("ASOS");
		dataheader.setSupplierId(resultsFC03.get(i)[4]);
		dataheader.setCarrierId(new Byte((byte)1));
		dataheader.setStationId("DOCDATA");
		dataheader.setUserId("003474");
		dataheader.setDstamp(new Long(bookingTimeStamp));
		dataheader.setUploaded("N");
		dataheader.setTimeZoneName("Europe/London");
		dataheader.setServiceLevel("");
		dataheader.setTrailerId("ex Holland");*/
		
		
		//FC01
		/*String bookingTimeStamp = resultsFC01.get(i)[3];
		System.out.println("bookingTimeStamp:" +bookingTimeStamp);

		dataheader.setRecordType("BKL");
		dataheader.setAction("E");
		dataheader.setCode("Add");
		dataheader.setBookrefId(resultsFC01.get(i)[5]);
		dataheader.setSiteId(resultsFC01.get(i)[6]);
		dataheader.setBookingDstamp(new Long(bookingTimeStamp));
		dataheader.setStatus("Scheduled");
		dataheader.setLocationId("EUROHUB");
		dataheader.setNoSlots(new Byte((byte) 4));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setEstimatedPallets(new Byte((byte)0));
		dataheader.setActualCartons(new Byte((byte)0));
		dataheader.setActualPallets(new Byte((byte)0));
		System.out.println("setReferenceId:" +resultsFC01.get(i)[2]);
		dataheader.setReferenceId(resultsFC01.get(i)[2]);
		dataheader.setReferenceType("Pre-Advised");
		dataheader.setClientId("ASOS");
		dataheader.setSupplierId(resultsFC01.get(i)[4]);
		dataheader.setCarrierId(new Byte((byte)1));
		dataheader.setStationId("DOCDATA");
		dataheader.setUserId("003474");
		dataheader.setDstamp(new Long(bookingTimeStamp));
		dataheader.setUploaded("N");
		dataheader.setTimeZoneName("Europe/London");
		dataheader.setServiceLevel("");
		dataheader.setTrailerId("ex Holland");*/
		
		
		
		return dataheader;
	}

	
	static int countOccurences(String str, String word)  
	{ 
	  
		String in = str;
		int count = 0;
		Pattern p = Pattern.compile(word);
		Matcher m = p.matcher( in );
		while (m.find()) {
			count++;
		}
	//	System.out.println(i); // Prints 2
		
	    return count; 
	} 
	
	
}
