package xmlcreator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class XmlFormatter {
	public static File finalXMLDirectory_FC01 = new File("C:\\Workspace\\bookingDates\\src\\test\\resources\\bookingDatesFilesFC01");
	public static File finalXMLDirectory_FC03 = new File("C:\\Workspace\\bookingDates\\src\\test\\resources\\bookingDatesFilesFC03");
	public static File finalXMLDirectory_FC04 = new File("C:\\Workspace\\bookingDates\\src\\test\\resources\\bookingDatesFilesFC04");
	public String format(String input) {
		return prettyFormat(input, "2");
	}

	public static String prettyFormat(String input, String indent) {
		Source xmlInput = new StreamSource(new StringReader(input));
		StringWriter stringWriter = new StringWriter();
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", indent);
			transformer.transform(xmlInput, new StreamResult(stringWriter));

			return stringWriter.toString().trim();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String args[]) throws IOException {
		int filecount=0;
		File[] finalXMLList_FC01 = finalXMLDirectory_FC01.listFiles();
	    System.out.println("Final List size:"+finalXMLList_FC01.length);
	    for (File tmp : finalXMLList_FC01){
	    	filecount++;
	    	String content = new String(Files.readAllBytes(Paths.get(tmp.getPath())));
	    	XmlFormatter formatter = new XmlFormatter();
			System.out.println(formatter.format(content));
			String xmlfileName = tmp.getName();
				File file = new File("src/test/resources/bookingDatesFilesFC01/" + xmlfileName);
				file.createNewFile();
				FileWriter fileWriter = new FileWriter(file);
				fileWriter.write(formatter.format(content));
				fileWriter.flush();
				fileWriter.close();
	    }
	    filecount=0;
	    File[] finalXMLList_FC03 = finalXMLDirectory_FC03.listFiles();
	    System.out.println("Final List size:"+finalXMLList_FC03.length);
	    for (File tmp : finalXMLList_FC03){
	    	filecount++;
	    	String content = new String(Files.readAllBytes(Paths.get(tmp.getPath())));
	    	XmlFormatter formatter = new XmlFormatter();
			System.out.println(formatter.format(content));
			String xmlfileName = tmp.getName();
				File file = new File("src/test/resources/bookingDatesFilesFC03/" + xmlfileName);
				file.createNewFile();
				FileWriter fileWriter = new FileWriter(file);
				fileWriter.write(formatter.format(content));
				fileWriter.flush();
				fileWriter.close();
	    }
	    filecount=0;
	    File[] finalXMLList_FC04 = finalXMLDirectory_FC04.listFiles();
	    System.out.println("Final List size:"+finalXMLList_FC04.length);
	    for (File tmp : finalXMLList_FC04){
	    	filecount++;
	    	String content = new String(Files.readAllBytes(Paths.get(tmp.getPath())));
	    	XmlFormatter formatter = new XmlFormatter();
			System.out.println(formatter.format(content));
			String xmlfileName = tmp.getName();
				File file = new File("src/test/resources/bookingDatesFilesFC04/" + xmlfileName);
				file.createNewFile();
				FileWriter fileWriter = new FileWriter(file);
				fileWriter.write(formatter.format(content));
				fileWriter.flush();
				fileWriter.close();
	    }
	}
}